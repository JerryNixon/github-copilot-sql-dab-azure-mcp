const CONFIG = {
    clientId: '5c67e613-c5e6-41d9-a992-27624194fc20',
    tenantId: 'eaf341ca-58d3-4d02-93c3-787dfe8e154f',
    apiUrlLocal: 'http://localhost:5000',
    apiUrlAzure: 'https://aca-dab-66b2sizc5g3ag.greenrock-c547df4e.centralus.azurecontainerapps.io'
};
